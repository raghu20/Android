package trainedge.recorder;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

import static android.media.MediaRecorder.OutputFormat.THREE_GPP;

public class MainActivity extends AppCompatActivity {
    Button play, stop, record;
    private MediaRecorder myAudioRecorder;
    private String outputFile = null;
    private static final String[] INITIAL_PREMS = {
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.WRITE_EXTERNAL_STORAGE};
    private static final int INITIAL_REQUEST = 1337;
    private Chronometer c;
    long timewhenstopped = 0;
    private TextView textView;


    @RequiresApi(api = Build.VERSION_CODES.M)
    private boolean canRecordAudio() {
        return (hasPermission(Manifest.permission.RECORD_AUDIO));
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private boolean canWriteExternalStorage() {
        return (hasPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE));
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private boolean hasPermission(String perm) {
        return (PackageManager.PERMISSION_GRANTED == checkSelfPermission(perm));
    }


    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == INITIAL_REQUEST) {
            if (canRecordAudio() && canWriteExternalStorage()) {
                canRecordAudio();
                canWriteExternalStorage();
            } else {
                Toast.makeText(this, "PERMISSION IS NECESSARY", Toast.LENGTH_SHORT).show();
            }
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!canRecordAudio() || !canWriteExternalStorage()) {
                requestPermissions(INITIAL_PREMS, INITIAL_REQUEST);
            }
        }
        textView = (TextView) findViewById(R.id.textView);
        play = (Button) findViewById(R.id.button3);
        stop = (Button) findViewById(R.id.button2);
        record = (Button) findViewById(R.id.button);
        c = (Chronometer) findViewById(R.id.chronometer);
        FloatingActionButton floatingActionButton= (FloatingActionButton) findViewById(R.id.fab);
        stop.setEnabled(false); // to disable button , it will enable after record button pressed<br />
        play.setEnabled(false);
        Long tsLong = System.currentTimeMillis() / 1000;
        String ts = tsLong.toString();
        outputFile = Environment.getExternalStorageDirectory().getAbsolutePath() + "/recording" + ts + ".3gp";


        record.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                myAudioRecorder = new MediaRecorder();

                myAudioRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                myAudioRecorder.setOutputFormat(THREE_GPP);
                myAudioRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
                myAudioRecorder.setOutputFile(outputFile);
                try {
                    myAudioRecorder.prepare();
                    myAudioRecorder.start();
                } catch (IllegalStateException e) {

                    e.printStackTrace();
                } catch (IOException e) {

                    e.printStackTrace();
                }
                record.setEnabled(false);
                stop.setEnabled(true);
                Toast.makeText(getApplicationContext(), "Recording started", Toast.LENGTH_LONG).show();
                c.setBase(SystemClock.elapsedRealtime() + timewhenstopped);
                c.start();

            }
        });
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myAudioRecorder.stop();
                myAudioRecorder.release();
                myAudioRecorder = null;
                stop.setEnabled(false);
                play.setEnabled(true);
                Toast.makeText(getApplicationContext(), "Audio recorded successfully", Toast.LENGTH_LONG).show();
                timewhenstopped = c.getBase() - SystemClock.elapsedRealtime();
                c.stop();


            }
        });
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) throws IllegalArgumentException, SecurityException, IllegalStateException {
                MediaPlayer m = new MediaPlayer();
                try {
                    m.setDataSource(outputFile);
                } catch (IOException e) {
                    e.printStackTrace();
                }
                try {
                    m.prepare();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                m.start();
                Toast.makeText(getApplicationContext(), "Playing audio", Toast.LENGTH_LONG).show();
                stop.setEnabled(true);
                play.setEnabled(false);
                record.setEnabled(true);
                c.setBase(SystemClock.elapsedRealtime());
                timewhenstopped = 0;
            }
        });
        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openFileManager();

            }

        });
    }

    public void openFileManager() {
        Uri selectedUri = Uri.parse(outputFile);
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setDataAndType(selectedUri, "video/3gpp");
        startActivity(Intent.createChooser(intent, getString(R.string.open_folder)));
    }
}